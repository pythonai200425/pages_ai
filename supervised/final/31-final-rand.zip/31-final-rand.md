# Random Forest

האם מודל Random Forest פותר בעיית קלסיפיקציה, רגרסיה או גם וגם?

---

מהו הרעיון המרכזי שעליו מבוסס מודל Random Forest?

כיצד Random Forest קשור למודל Decision Tree?

---

מהו Bootstrap Sampling וכיצד הוא משמש ב־Random Forest?

---

מדוע השימוש באקראיות משפר את ביצועי המודל?

---

כיצד מתקבלת התחזית הסופית ב־Random Forest לקלסיפיקציה?

מהו מנגנון ההצבעה (Voting) ב־Random Forest וכיצד הוא פועל?

---

כיצד מתקבלת התחזית הסופית ב־Random Forest לרגרסיה?

---

אילו Hyperparameters נפוצים קיימים במודל Random Forest?

---

מהו OOB Error (Out-Of-Bag Error) וכיצד משתמשים בו להערכת ביצועי המודל?

---

מה היתרון של Random Forest מבחינת יציבות המודל לעומת Decision Tree?

---

אילו מדדי ביצוע מתאימים להערכת מודל Random Forest בקלסיפיקציה וברגרסיה?

---

יש לשלוח את הפתרון למייל:
📧 [pythonai200425+supfinal@gmail.com](mailto:pythonai200425+supfinal@gmail.com)
